"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
class OptionsUIController {
    constructor(status) {
        this.status = status;
        this.elRunningRow = document.querySelector("#runningRow");
        this.elBreakTimeLengthMin = document.querySelector("#breakTimeLength");
        this.elMatches = document.querySelector("#matches");
        this.elReset = document.querySelector("#reset");
        this.elRevert = document.querySelector("#revert");
    }
    /**
     * (milliseconds)
     */
    get breakTimeLength() {
        return Number(this.elBreakTimeLengthMin.value) * 1000 * 60;
    }
    start() {
        return __awaiter(this, void 0, void 0, function* () {
            this.status.onChange(() => {
                this.render();
            });
            this.elBreakTimeLengthMin.addEventListener("input", (event) => this.onBreakTimeLengthMinChange(event));
            this.elBreakTimeLengthMin.addEventListener("keydown", (event) => this.onBreakTimeLengthMinChange(event));
            this.elMatches.addEventListener("input", () => {
                this.status.setMatches(this.elMatches.value.split("\n"));
            });
            this.elReset.addEventListener("click", () => {
                this.status.reset();
            });
            this.elRevert.addEventListener("click", () => {
                this.status.revert();
            });
            yield this.status.init();
            this.render();
        });
    }
    onBreakTimeLengthMinChange(event) {
        // Edge doesn't recognize update when you use up/down keys.
        // They fixed that but not have shipped.
        // TODO remove keydown stuff and simplify when shipped
        // https://developer.microsoft.com/en-us/microsoft-edge/platform/issues/14678823/
        const update = () => {
            const length = this.breakTimeLength;
            if (length > 0) {
                this.status.setBreakTimeLength(length);
            }
        };
        if (event.type === "keydown") {
            setTimeout(update, 1);
        }
        else {
            update();
        }
    }
    render() {
        this.elRunningRow.setAttribute("data-status", this.status.text);
        const sBreakTimeLengthMin = Math.floor(this.status.breakTimeLength / 60 / 1000).toString();
        this.elBreakTimeLengthMin.value = sBreakTimeLengthMin;
        this.elMatches.value = this.status.matchesText;
        this.elRevert.disabled = !this.status.modified;
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiT3B0aW9uc1VJQ29udHJvbGxlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIk9wdGlvbnNVSUNvbnRyb2xsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUE7SUFjRSxZQUE4QixNQUFjO1FBQWQsV0FBTSxHQUFOLE1BQU0sQ0FBUTtRQWIzQixpQkFBWSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFFLENBQUM7UUFDdEQseUJBQW9CLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBcUIsQ0FBQztRQUN0RixjQUFTLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQXdCLENBQUM7UUFDdEUsWUFBTyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFFLENBQUM7UUFDNUMsYUFBUSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFzQixDQUFDO0lBVW5GLENBQUM7SUFSRDs7T0FFRztJQUNILElBQUksZUFBZTtRQUNqQixPQUFPLE1BQU0sQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztJQUM3RCxDQUFDO0lBS1ksS0FBSzs7WUFDaEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFO2dCQUN4QixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDaEIsQ0FBQyxDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsb0JBQW9CLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsMEJBQTBCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUN2RyxJQUFJLENBQUMsb0JBQW9CLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsMEJBQTBCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUV6RyxJQUFJLENBQUMsU0FBUyxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxHQUFHLEVBQUU7Z0JBQzVDLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQzNELENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsR0FBRyxFQUFFO2dCQUMxQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ3RCLENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsR0FBRyxFQUFFO2dCQUMzQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ3ZCLENBQUMsQ0FBQyxDQUFDO1lBRUgsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ3pCLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNoQixDQUFDO0tBQUE7SUFFTywwQkFBMEIsQ0FBRSxLQUFZO1FBQzlDLDJEQUEyRDtRQUMzRCx3Q0FBd0M7UUFDeEMsc0RBQXNEO1FBQ3RELGlGQUFpRjtRQUNqRixNQUFNLE1BQU0sR0FBRyxHQUFHLEVBQUU7WUFDbEIsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQztZQUNwQyxJQUFJLE1BQU0sR0FBRyxDQUFDLEVBQUU7Z0JBQ2QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsQ0FBQzthQUN4QztRQUNILENBQUMsQ0FBQztRQUVGLElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxTQUFTLEVBQUU7WUFDNUIsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQztTQUN2QjthQUFNO1lBQ0wsTUFBTSxFQUFFLENBQUM7U0FDVjtJQUNILENBQUM7SUFFTyxNQUFNO1FBQ1osSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFaEUsTUFBTSxtQkFBbUIsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUMzRixJQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSyxHQUFHLG1CQUFtQixDQUFDO1FBRXRELElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDO1FBRS9DLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7SUFDakQsQ0FBQztDQUNGIn0=