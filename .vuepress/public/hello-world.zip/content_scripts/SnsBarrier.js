"use strict";
class SnsBarrier {
    constructor(status) {
        this.status = status;
        this.tmShow = 0;
    }
    reset() {
        clearTimeout(this.tmShow);
        const el = document.querySelector("#stopSns");
        if (el && el.parentElement) {
            el.parentElement.removeChild(el);
        }
        document.body.style.overflow = "";
    }
    show() {
        this.reset();
        const el = this.buildElements();
        if (!el) {
            throw new Error("Failed to build the element");
        }
        const okButton = el.querySelector(".stopSns-ok");
        if (okButton) {
            okButton.addEventListener("click", (event) => {
                this.reset();
                this.startBreaking();
            });
        }
        document.body.appendChild(el);
        document.body.style.overflow = "hidden";
    }
    startBreaking() {
        this.status.startBreaking();
        // break will be stopped by status
    }
    buildElements() {
        function _createElement(html) {
            const builder = document.createElement("div");
            builder.innerHTML = html.trim();
            const el = builder.firstElementChild;
            return el;
        }
        return _createElement(`
      <div id="stopSns">
        <div class="stopSns-content">
          <h1 class="stopSns-message">🛇</h1>
          <div>
            <button class="stopSns-ok">Unleash your desire...</button>
          </div>
        </div>
      </div>
    `);
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiU25zQmFycmllci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIlNuc0JhcnJpZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBO0lBR0UsWUFBOEIsTUFBYztRQUFkLFdBQU0sR0FBTixNQUFNLENBQVE7UUFGcEMsV0FBTSxHQUFHLENBQUMsQ0FBQztJQUduQixDQUFDO0lBRU0sS0FBSztRQUNWLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFMUIsTUFBTSxFQUFFLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUM5QyxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsYUFBYSxFQUFFO1lBQzFCLEVBQUUsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQ2xDO1FBQ0QsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQztJQUNwQyxDQUFDO0lBRU0sSUFBSTtRQUNULElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUViLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNoQyxJQUFJLENBQUMsRUFBRSxFQUFFO1lBQ1AsTUFBTSxJQUFJLEtBQUssQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1NBQ2hEO1FBRUQsTUFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUNqRCxJQUFJLFFBQVEsRUFBRTtZQUNaLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRTtnQkFDM0MsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO2dCQUNiLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUN2QixDQUFDLENBQUMsQ0FBQztTQUNKO1FBRUQsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDOUIsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztJQUMxQyxDQUFDO0lBRU0sYUFBYTtRQUNsQixJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBRTVCLGtDQUFrQztJQUNwQyxDQUFDO0lBRU8sYUFBYTtRQUNuQix3QkFBeUIsSUFBWTtZQUNuQyxNQUFNLE9BQU8sR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzlDLE9BQU8sQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1lBQ2hDLE1BQU0sRUFBRSxHQUFHLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQztZQUNyQyxPQUFPLEVBQUUsQ0FBQztRQUNaLENBQUM7UUFFRCxPQUFPLGNBQWMsQ0FBQzs7Ozs7Ozs7O0tBU3JCLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRiJ9